package model;

public class ProcessT {

	private String name;
	private String pID;
	private String sessionName;
	private String sessionNo;
	private String memoryUsage;

	public ProcessT() {

	}

	public ProcessT(String name, String pID, String sessionName, String sessionNo, String memoryUsage) {
		super();
		this.name = name;
		this.pID = pID;
		this.sessionName = sessionName;
		this.sessionNo = sessionNo;
		this.memoryUsage = memoryUsage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPID() {
		return pID;
	}

	public void setPID(String pID) {
		this.pID = pID;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public String getSessionNo() {
		return sessionNo;
	}

	public void setSessionNo(String sessionNo) {
		this.sessionNo = sessionNo;
	}

	public String getMemoryUsage() {
		return memoryUsage;
	}

	public void setMemoryUsage(String memoryUsage) {
		this.memoryUsage = memoryUsage;
	}

	@Override
	public String toString() {
		return "Process [name=" + name + ", PID=" + pID + ", sessionName=" + sessionName + ", sessionNo=" + sessionNo + ", memoryUsage="
				+ memoryUsage + "]";
	}

}
