package model;

public interface Monitor {

	void calculate();
	void createComponents();
	void initiliaze();
	void listComponents();
	void loadCommand();
	void refresh();

	
}
