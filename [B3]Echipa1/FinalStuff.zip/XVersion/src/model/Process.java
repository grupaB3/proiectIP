package model;

public class Process extends Component{

	private String name;
	private String processId;
	private String sessionId;
	private String threadCount;
	private String kernelModeTime;
	private String userModeTime;
	private String workingSetSize;
	private String virtualSize;
	private String pageFileCount;
	private String pageFileUsage;
	private String privatePageCount;
	private String readOperationCount;
	private String writeOperationCount;
	private String readTransferCount;
	private String writeTransferCount;

	public Process() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getThreadCount() {
		return threadCount;
	}

	public void setThreadCount(String threadCount) {
		this.threadCount = threadCount;
	}

	public String getKernelModeTime() {
		return kernelModeTime;
	}

	public void setKernelModeTime(String kernelModeTime) {
		this.kernelModeTime = kernelModeTime;
	}

	public String getUserModeTime() {
		return userModeTime;
	}

	public void setUserModeTime(String userModeTime) {
		this.userModeTime = userModeTime;
	}

	public String getWorkingSetSize() {
		return workingSetSize;
	}

	public void setWorkingSetSize(String workingSetSize) {
		this.workingSetSize = workingSetSize;
	}

	public String getVirtualSize() {
		return virtualSize;
	}

	public void setVirtualSize(String virtualSize) {
		this.virtualSize = virtualSize;
	}

	public String getPageFileCount() {
		return pageFileCount;
	}

	public void setPageFileCount(String pageFileCount) {
		this.pageFileCount = pageFileCount;
	}

	public String getPageFileUsage() {
		return pageFileUsage;
	}

	public void setPageFileUsage(String pageFileUsage) {
		this.pageFileUsage = pageFileUsage;
	}

	public String getPrivatePageCount() {
		return privatePageCount;
	}

	public void setPrivatePageCount(String privatePageCount) {
		this.privatePageCount = privatePageCount;
	}

	public String getReadOperationCount() {
		return readOperationCount;
	}

	public void setReadOperationCount(String readOperationCount) {
		this.readOperationCount = readOperationCount;
	}

	public String getWriteOperationCount() {
		return writeOperationCount;
	}

	public void setWriteOperationCount(String writeOperationCount) {
		this.writeOperationCount = writeOperationCount;
	}

	public String getReadTransferCount() {
		return readTransferCount;
	}

	public void setReadTransferCount(String readTransferCount) {
		this.readTransferCount = readTransferCount;
	}

	public String getWriteTransferCount() {
		return writeTransferCount;
	}

	public void setWriteTransferCount(String writeTransferCount) {
		this.writeTransferCount = writeTransferCount;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Process [name=");
		builder.append(name);
		builder.append(", processId=");
		builder.append(processId);
		builder.append(", sessionId=");
		builder.append(sessionId);
		builder.append(", threadCount=");
		builder.append(threadCount);
		builder.append(", kernelModeTime=");
		builder.append(kernelModeTime);
		builder.append(", userModeTime=");
		builder.append(userModeTime);
		builder.append(", workingSetSize=");
		builder.append(workingSetSize);
		builder.append(", virtualSize=");
		builder.append(virtualSize);
		builder.append(", pageFileCount=");
		builder.append(pageFileCount);
		builder.append(", pageFileUsage=");
		builder.append(pageFileUsage);
		builder.append(", privatePageCount=");
		builder.append(privatePageCount);
		builder.append(", readOperationCount=");
		builder.append(readOperationCount);
		builder.append(", writeOperationCount=");
		builder.append(writeOperationCount);
		builder.append(", readTransferCount=");
		builder.append(readTransferCount);
		builder.append(", writeTransferCount=");
		builder.append(writeTransferCount);
		builder.append("]");
		return builder.toString();
	}

	
}
