/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.controller;

import java.util.List;
import model.ProcessT;
import controller.ProcessMonitor;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProcessMonitorTest {

	public ProcessMonitorTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of getNumberOfProcesses method, of class ProcessMonitor.
	 */
	@Test
	public void testGetNumberOfProcesses() {
		System.out.println("getNumberOfProcesses");
		ProcessMonitor instance = new ProcessMonitor();
		int expResult = 0;
		int result = instance.getNumberOfProcesses();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of setNumberOfProcesses method, of class ProcessMonitor.
	 */
	@Test
	public void testSetNumberOfProcesses() {
		System.out.println("setNumberOfProcesses");
		int numberOfProcesses = 0;
		ProcessMonitor instance = new ProcessMonitor();
		instance.setNumberOfProcesses(numberOfProcesses);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of getTotalCPU method, of class ProcessMonitor.
	 */
	@Test
	public void testGetTotalCPU() {
		System.out.println("getTotalCPU");
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = "";
		String result = instance.getTotalCPU();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of setTotalCPU method, of class ProcessMonitor.
	 */
	@Test
	public void testSetTotalCPU() {
		System.out.println("setTotalCPU");
		String totalCPU = "";
		ProcessMonitor instance = new ProcessMonitor();
		instance.setTotalCPU(totalCPU);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of getTotalMemory method, of class ProcessMonitor.
	 */
	@Test
	public void testGetTotalMemory() {
		System.out.println("getTotalMemory");
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = "";
		String result = instance.getTotalMemory();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of setTotalMemory method, of class ProcessMonitor.
	 */
	@Test
	public void testSetTotalMemory() {
		System.out.println("setTotalMemory");
		String totalMemory = "";
		ProcessMonitor instance = new ProcessMonitor();
		instance.setTotalMemory(totalMemory);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of getTxtFileName method, of class ProcessMonitor.
	 */
	@Test
	public void testGetTxtFileName() {
		System.out.println("getTxtFileName");
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = System.getProperty("user.dir")
				+ "\\processesList.txt";
		String result = instance.getTxtFileName();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of setTxtFileName method, of class ProcessMonitor.
	 */
	@Test
	public void testSetTxtFileName() {
		System.out.println("setTxtFileName");
		String txtFileName = "";
		ProcessMonitor instance = new ProcessMonitor();
		instance.setTxtFileName(txtFileName);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of isTxtCreated method, of class ProcessMonitor.
	 */
	@Test
	public void testIsTxtCreated() {
		System.out.println("isTxtCreated");
		ProcessMonitor instance = new ProcessMonitor();
		boolean expResult = false;
		boolean result = instance.isTxtCreated();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of setTxtCreated method, of class ProcessMonitor.
	 */
	@Test
	public void testSetTxtCreated() {
		System.out.println("setTxtCreated");
		boolean isTxtCreated = false;
		ProcessMonitor instance = new ProcessMonitor();
		instance.setTxtCreated(isTxtCreated);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of getProcessList method, of class ProcessMonitor.
	 */
	@Test
	public void testGetProcessList() {
		System.out.println("getProcessList");
		ProcessMonitor instance = new ProcessMonitor();
		List<ProcessT> expResult = null;
		List<ProcessT> result = instance.getProcessList();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of setProcessList method, of class ProcessMonitor.
	 */
	@Test
	public void testSetProcessList() {
		System.out.println("setProcessList");
		List<ProcessT> processList = null;
		ProcessMonitor instance = new ProcessMonitor();
		instance.setProcessList(processList);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of isListCreated method, of class ProcessMonitor.
	 */
	@Test
	public void testIsListCreated() {
		System.out.println("isListCreated");
		ProcessMonitor instance = new ProcessMonitor();
		boolean expResult = false;
		boolean result = instance.isListCreated();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of setListCreated method, of class ProcessMonitor.
	 */
	@Test
	public void testSetListCreated() {
		System.out.println("setListCreated");
		boolean isListCreated = false;
		ProcessMonitor instance = new ProcessMonitor();
		instance.setListCreated(isListCreated);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of getAdminPassword method, of class ProcessMonitor.
	 */
	@Test
	public void testGetAdminPassword() {
		System.out.println("getAdminPassword");
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = null;
		String result = instance.getAdminPassword();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of setAdminPassword method, of class ProcessMonitor.
	 */
	@Test
	public void testSetAdminPassword() {
		System.out.println("setAdminPassword");
		String adminPassword = "";
		ProcessMonitor instance = new ProcessMonitor();
		instance.setAdminPassword(adminPassword);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of isPasswordSet method, of class ProcessMonitor.
	 */
	@Test
	public void testIsPasswordSet() {
		System.out.println("isPasswordSet");
		ProcessMonitor instance = new ProcessMonitor();
		boolean expResult = false;
		boolean result = instance.isPasswordSet();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of setPasswordSet method, of class ProcessMonitor.
	 */
	@Test
	public void testSetPasswordSet() {
		System.out.println("setPasswordSet");
		boolean isPasswordSet = false;
		ProcessMonitor instance = new ProcessMonitor();
		instance.setPasswordSet(isPasswordSet);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	// TEST 1 ok
	/**
	 * Test of connect method, of class ProcessMonitor.
	 */
	@Test
	public void testConnect() {
		System.out.println("connect");
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = "Succes @connect";
		// String expResult = "Failed @connect";
		String result = instance.connect();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	// TEST 2 ok
	/**
	 * Test of parse method, of class ProcessMonitor.
	 */
	@Test
	public void testParse() {
		System.out.println("parse");
		ProcessMonitor instance = new ProcessMonitor();
		instance.connect();
		String expResult = "Succes @parse";
		// String expResult = "Failed @parse";
		String result = instance.parse();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	// TEST 6
	/**
	 * Test of setTotalProcessesNo method, of class ProcessMonitor.
	 */
	@Test
	public void testSetTotalProcessesNo() {
		System.out.println("setTotalProcessesNo");
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = "Succes @setTotalProcessesNo";
		String result = instance.setTotalProcessesNo();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	/**
	 * Test of listProcesses method, of class ProcessMonitor.
	 */
	@Test
	public void testListProcesses() {
		System.out.println("listProcesses");
		ProcessMonitor instance = new ProcessMonitor();
		instance.listProcesses();
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	// TEST 3 ok
	/**
	 * Test of create method, of class ProcessMonitor.
	 */
	@Test
	public void testCreate() {
		System.out.println("create");
		// String name = "swipl-win.exe";
		// String name = "uTorrent.exe";
		String name = "C:\\Program Files\\Sublime Text 3\\sublime_text.exe";// notepad.exe;
																			// calc.exe;
																			// mspaint.exe;
																			// sublime_text.exe;
																			// sublime_text.exe
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = "Succes @create";
		// String expResult = "Failed @create";
		String result = instance.create(name);
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	// TEST 4 ok
	/**
	 * Test of delete method, of class ProcessMonitor.
	 */
	@Test
	public void testDelete() {
		System.out.println("delete");
		String pID = "5188";
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = "Succes @delete";
		instance.connect();
		instance.parse();
		String result = instance.delete(pID);
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	// TEST 5
	/**
	 * Test of totalCpuUsage method, of class ProcessMonitor.
	 */
	@Test
	public void testTotalCpuUsage() {
		System.out.println("totalCpuUsage");
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = "Succes @totalCpuUsage";
		String result = instance.totalCpuUsage();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

	// TEST 6
	/**
	 * Test of totalMemoryUsage method, of class ProcessMonitor.
	 */
	@Test
	public void testTotalMemoryUsage() {
		System.out.println("totalMemoryUsage");
		ProcessMonitor instance = new ProcessMonitor();
		String expResult = "Succes @totalMemoryUsage";
		String result = instance.totalMemoryUsage();
		assertEquals(expResult, result);
		// TODO review the generated test code and remove the default call to
		// fail.
		// fail("The test case is a prototype.");
	}

}
