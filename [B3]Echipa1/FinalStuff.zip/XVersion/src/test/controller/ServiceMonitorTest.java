/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test.controller;

import controller.ServiceMonitor;
import java.util.List;
import model.Service;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class ServiceMonitorTest {
    
    public ServiceMonitorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getServicesListTxt method, of class ServiceMonitor.
     */
    @Test
    public void testGetServicesListTxt() {
        System.out.println("getServicesListTxt");
        ServiceMonitor instance = new ServiceMonitor();
        String expResult = "";
        String result = instance.getServicesListTxt();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setServicesListTxt method, of class ServiceMonitor.
     */
    @Test
    public void testSetServicesListTxt() {
        System.out.println("setServicesListTxt");
        String servicesListTxt = "";
        ServiceMonitor instance = new ServiceMonitor();
        instance.setServicesListTxt(servicesListTxt);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getAdminPassword method, of class ServiceMonitor.
     */
    @Test
    public void testGetAdminPassword() {
        System.out.println("getAdminPassword");
        ServiceMonitor instance = new ServiceMonitor();
        String expResult = "";
        String result = instance.getAdminPassword();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setAdminPassword method, of class ServiceMonitor.
     */
    @Test
    public void testSetAdminPassword() {
        System.out.println("setAdminPassword");
        String adminPassword = "";
        ServiceMonitor instance = new ServiceMonitor();
        instance.setAdminPassword(adminPassword);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of isTxtCreated method, of class ServiceMonitor.
     */
    @Test
    public void testIsTxtCreated() {
        System.out.println("isTxtCreated");
        ServiceMonitor instance = new ServiceMonitor();
        boolean expResult = false;
        boolean result = instance.isTxtCreated();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setTxtCreated method, of class ServiceMonitor.
     */
    @Test
    public void testSetTxtCreated() {
        System.out.println("setTxtCreated");
        boolean txtCreated = false;
        ServiceMonitor instance = new ServiceMonitor();
        instance.setTxtCreated(txtCreated);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of isPasswordSet method, of class ServiceMonitor.
     */
    @Test
    public void testIsPasswordSet() {
        System.out.println("isPasswordSet");
        ServiceMonitor instance = new ServiceMonitor();
        boolean expResult = false;
        boolean result = instance.isPasswordSet();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setPasswordSet method, of class ServiceMonitor.
     */
    @Test
    public void testSetPasswordSet() {
        System.out.println("setPasswordSet");
        boolean isPasswordSet = false;
        ServiceMonitor instance = new ServiceMonitor();
        instance.setPasswordSet(isPasswordSet);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of isHasStarted method, of class ServiceMonitor.
     */
    @Test
    public void testIsHasStarted() {
        System.out.println("isHasStarted");
        ServiceMonitor instance = new ServiceMonitor();
        boolean expResult = false;
        boolean result = instance.isHasStarted();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setHasStarted method, of class ServiceMonitor.
     */
    @Test
    public void testSetHasStarted() {
        System.out.println("setHasStarted");
        boolean hasStarted = false;
        ServiceMonitor instance = new ServiceMonitor();
        instance.setHasStarted(hasStarted);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of isHasStopped method, of class ServiceMonitor.
     */
    @Test
    public void testIsHasStopped() {
        System.out.println("isHasStopped");
        ServiceMonitor instance = new ServiceMonitor();
        boolean expResult = false;
        boolean result = instance.isHasStopped();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setHasStopped method, of class ServiceMonitor.
     */
    @Test
    public void testSetHasStopped() {
        System.out.println("setHasStopped");
        boolean hasStopped = false;
        ServiceMonitor instance = new ServiceMonitor();
        instance.setHasStopped(hasStopped);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getServicesList method, of class ServiceMonitor.
     */
    @Test
    public void testGetServicesList() {
        System.out.println("getServicesList");
        ServiceMonitor instance = new ServiceMonitor();
        List<Service> expResult = null;
        List<Service> result = instance.getServicesList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setServicesList method, of class ServiceMonitor.
     */
    @Test
    public void testSetServicesList() {
        System.out.println("setServicesList");
        List<Service> servicesList = null;
        ServiceMonitor instance = new ServiceMonitor();
        instance.setServicesList(servicesList);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of removeComponentFromList method, of class ServiceMonitor.
     */
    @Test
    public void testRemoveComponentFromList() {
        System.out.println("removeComponentFromList");
        Object component = null;
        ServiceMonitor instance = new ServiceMonitor();
        instance.initiliaze();
        instance.connect();
        instance.removeComponentFromList(component);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of addComponentToList method, of class ServiceMonitor.
     */
    @Test
    public void testAddComponentToList() {
        System.out.println("addComponentToList");
        Object component = null;
        ServiceMonitor instance = new ServiceMonitor();
        instance.initiliaze();
        instance.connect();
        instance.addComponentToList(component);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
    // TEST 5 ok
    /**
     * Test of connect method, of class ServiceMonitor.
     */
    @Test
    public void testConnect() {
        System.out.println("connect");
        ServiceMonitor instance = new ServiceMonitor();
        instance.initiliaze();
        instance.connect();
        String expResult = "Succes @connect";
        //String expResult = "Failed @connect";
        String result = instance.connect();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of listComponents method, of class ServiceMonitor.
     */
    @Test
    public void testListComponents() {
        System.out.println("listComponents");
        ServiceMonitor instance = new ServiceMonitor();
        instance.initiliaze();
        instance.connect();
        instance.listComponents();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
    
    // TEST 6 ok
    /**
     * Test of parse method, of class ServiceMonitor.
     */
    @Test
    public void testParse() {
        System.out.println("parse");
        ServiceMonitor instance = new ServiceMonitor();
        instance.initiliaze();
        instance.connect();
        String expResult = "Succes @parse";
        //String expResult = "Failed @parse";
        String result = instance.parse();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
    
    /**
     * Test of refresh method, of class ServiceMonitor.
     */
    @Test
    public void testRefresh() {
        System.out.println("refresh");
        ServiceMonitor instance = new ServiceMonitor();
        instance.initiliaze();
        instance.connect();
        instance.refresh();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of initiliaze method, of class ServiceMonitor.
     */
    @Test
    public void testInitiliaze() {
        System.out.println("initiliaze");
        ServiceMonitor instance = new ServiceMonitor();
        instance.initiliaze();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
    // TEST 7
    /**
     * Test of start method, of class ServiceMonitor.
     */
    @Test
    public void testStart() {
        System.out.println("start");
//        String name = "OracleXEClrAgent";
        String name = "MozillaMaintenance";
        ServiceMonitor instance = new ServiceMonitor();
        String expResult = "Succes @start";
        //String expResult = "Failed @start";
        instance.initiliaze();
        instance.connect();
        instance.parse();
        instance.start(name);
        String result = instance.checkIfStarted(name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
    // TEST 8
    /**
     * Test of stop method, of class ServiceMonitor.
     */
    @Test
    public void testStop() {
        System.out.println("stop");
        String name = "MozillaMaintenance";
        //String name = "OracleXETNSListener";
        ServiceMonitor instance = new ServiceMonitor();
        String expResult = "Succes @stop";
        //String expResult = "Failed @stop";
        instance.initiliaze();
        instance.connect();
        instance.parse();
        instance.stop(name);
        String result = instance.checkIfStopped(name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
    // TEST 9
    /**
     * Test of changeStartup method, of class ServiceMonitor.
     */
    @Test
    public void testChangeStartup() {
        System.out.println("changeStartup");
        String name = "OracleServiceXE";
        String mode = "demand";
        ServiceMonitor instance = new ServiceMonitor();
        String expResult = "Succes @changeStartup";
        //String expResult = "Failed @changeStartup";
        String result = instance.changeStartup(name, mode);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of runningServices method, of class ServiceMonitor.
     */
    @Test
    public void testRunningServices() {
        System.out.println("runningServices");
        ServiceMonitor instance = new ServiceMonitor();
        List<Service> expResult = null;
        instance.initiliaze();
        instance.connect();
        List<Service> result = instance.runningServices();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of stoppedServices method, of class ServiceMonitor.
     */
    @Test
    public void testStoppedServices() {
        System.out.println("stoppedServices");
        ServiceMonitor instance = new ServiceMonitor();
        instance.initiliaze();
        instance.connect();
        instance.ordonateByState(false);
        List<Service> expResult = null;
        List<Service> result = instance.stoppedServices();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of ordonateByState method, of class ServiceMonitor.
     */
    @Test
    public void testOrdonateByState() {
        System.out.println("ordonateByState");
        String expResult = "runningFirst";
        Boolean runningFirst = true;
        ServiceMonitor instance = new ServiceMonitor();
        instance.initiliaze();
        instance.connect();
        instance.ordonateByState(runningFirst);
        String result = instance.ordonateByState(runningFirst);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
