package application;

import controller.ProcessMonitor;
import controller.ServiceMonitor;

public class MainTester {

	public static void main(String[] args) {
		ProcessMonitor pm = new ProcessMonitor();
//		pm.totalCpuUsage();
//		pm.totalMemoryUsage();
//		System.out.println(pm.connect());
//		System.out.println(pm.parse());
//		System.out.println(pm.setTotalProcessesNo());
//		pm.listProcesses();
//		pm.delete("3436");
//		System.out.println(pm.create("calc.exe"));
//		System.out.println(pm.create("notepad.exe"));
//		System.out.println(pm.delete("4528"));
		ServiceMonitor sm = new ServiceMonitor();
		sm.initiliaze();
		System.out.println(sm.connect());
		System.out.println(sm.parse());
		sm.listComponents();
        sm.start("TeamViewer");	
        sm.stop("MpsSvc"); 
        sm.changeStartup("OracleServiceXE", "demand");
	}

}
