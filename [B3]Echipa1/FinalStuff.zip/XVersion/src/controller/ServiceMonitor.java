package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import model.Service;

public class ServiceMonitor {

	private List<Service> servicesList;
	private String servicesListTxt;

	private String adminPassword;// = "27121969";
	//private String adminTxt;// = "C:\\Users\\Diana\\Desktop\\pass.txt";

	private boolean txtCreated = false;
	private boolean isPasswordSet = false;
	private boolean hasStarted = false;
	private boolean hasStopped = false;

	public String getServicesListTxt() {
		return servicesListTxt;
	}

	public void setServicesListTxt(String servicesListTxt) {
		this.servicesListTxt = servicesListTxt;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	public boolean isTxtCreated() {
		return txtCreated;
	}

	public void setTxtCreated(boolean txtCreated) {
		this.txtCreated = txtCreated;
	}

	public boolean isPasswordSet() {
		return isPasswordSet;
	}

	public void setPasswordSet(boolean isPasswordSet) {
		this.isPasswordSet = isPasswordSet;
	}

	public boolean isHasStarted() {
		return hasStarted;
	}

	public void setHasStarted(boolean hasStarted) {
		this.hasStarted = hasStarted;
	}

	public boolean isHasStopped() {
		return hasStopped;
	}

	public void setHasStopped(boolean hasStopped) {
		this.hasStopped = hasStopped;
	}

	public List<Service> getServicesList() {
		return servicesList;
	}

	public void setServicesList(List<Service> servicesList) {
		this.servicesList = servicesList;
	}

	public void removeComponentFromList(Object component) {
		servicesList.remove(component);
	}

	public void addComponentToList(Object component) {
		servicesList.add((Service) component);
	}

	public String connect() {
		try {
			List<String> command = new ArrayList<String>();
			command.add("cmd.exe");
			command.add("/c");
			command.add("sc");
			command.add("queryEx");
			command.add("state=");
			command.add("all");
			command.add(">");
			command.add(servicesListTxt);
			Process servicesProcess = new ProcessBuilder(command).start();
			InputStream input = servicesProcess.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));
			String line;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
			if(new File(servicesListTxt).exists()){
				this.txtCreated = true;
				return "Succes @connect";
			}
			else{
				return "Failed @connect";
			}
		} catch (IOException e) {
			return "Failed @connect";
		}
	}

	public void listComponents() {
		if (servicesList.size() == 0) {
			return;
		}
		for (Service service : servicesList) {
			System.out.println(service.toString());
		}
		System.out.println("PrintComponentsList completed succesfully!");
	}

	public String parse() {
		if (!txtCreated) {
			return "Failed @parse";
		}
		BufferedReader reader;
		String line;
		try {
			reader = new BufferedReader(new FileReader(this.servicesListTxt));
			line = reader.readLine();
			List<String> servicesNames = new ArrayList<String>();
			List<String> states = new ArrayList<String>();
			//List<String> descriptions = new ArrayList<String>();
			List<Integer> PIDs = new ArrayList<Integer>();
			List<String> startModes = new ArrayList<String>();
			while (line != null) {
				if (line.contains("SERVICE_NAME")) {
					servicesNames.add(line.substring(14));
				} else if (line.contains("STATE")) {
					states.add(line.substring(line.lastIndexOf(": ") + 2));
				} else if (line.contains("PID")) {
					PIDs.add(Integer.valueOf(line.substring(line.lastIndexOf(": ") + 2)));
				}
				line = reader.readLine();
			}
			/*for (String name : servicesNames) {
				List<String> command = new ArrayList<String>();
				command.add("cmd.exe");
				command.add("/c");
				command.add("sc");
				command.add("Qdescription");
				command.add(name);
				Process servicesProcess = new ProcessBuilder(command).start();
				InputStream input = servicesProcess.getInputStream();
				BufferedReader descriptionReader = new BufferedReader(new InputStreamReader(input));
				while ((line = descriptionReader.readLine()) != null) {
					if (line.toLowerCase().contains("description")) {
						descriptions.add(line.substring(line.lastIndexOf(":") + 3));
					}
				}
			}*/
			for (String name : servicesNames) {
				List<String> command = new ArrayList<String>();
				command.add("cmd.exe");
				command.add("/c");
				command.add("sc");
				command.add("qc");
				command.add(name);
				Process servicesProcess = new ProcessBuilder(command).start();
				InputStream input = servicesProcess.getInputStream(); 
				BufferedReader startModeReader = new BufferedReader(new InputStreamReader(input));
				while ((line = startModeReader.readLine()) != null) {
					if (line.contains("START_TYPE")) {
						startModes.add(line.substring(line.lastIndexOf(":") + 1));
					}
				}
				startModeReader.close();
			}
			System.out.println(servicesNames.size() + "   " + startModes.size());
			for (int i = 0; i < servicesNames.size(); i++) {
				Service service = new Service();
				service.setName(servicesNames.get(i));
				service.setState(states.get(i));
				//service.setDescription(descriptions.get(i));
				service.setPID(PIDs.get(i));
				service.setStartMode(startModes.get(i));
				servicesList.add(service);
			}
			reader.close();
			return "Succes @parse";
		} catch (IOException e) {
			return "Failed @parse";
		}
	}

	public void refresh() {
		connect();
		parse();
		listComponents();
		System.out.println("Refresh completed succesfully!");
	}

	public void initiliaze() {
		servicesList = new ArrayList<Service>();
		String workingDirectory = System.getProperty("user.dir");
		this.servicesListTxt = workingDirectory + "\\servicesList.txt";
		System.out.println("Initialize completed succesfully!");
	}

	public String start(String name) {
		try {
			List<String> command = new ArrayList<String>();
			command.add("cmd.exe");
			command.add("/c");
			command.add("sc");
			command.add("start");
			command.add(name);
			System.out.println(command);
			Process servicesProcess = new ProcessBuilder(command).start();
			InputStream input = servicesProcess.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));
			String line;
			StringBuffer queryResult = new StringBuffer();
			while ((line = reader.readLine()) != null) {
				queryResult.append(line);
			}
			reader.close();
			servicesProcess.destroy();
			if (queryResult.toString().toLowerCase().contains("failed") || queryResult.toString().toLowerCase().contains("error")) {
				return "Failed @start";
			}
			System.out.println("Start service completed succesfully! " + queryResult.toString());
		} catch (IOException e) {
			return "Failed @start";
		}
		return "Succes @start";
	}

	public String stop(String name) {
		try {
			List<String> command = new ArrayList<String>();
			// runas /user:Administrator â€œcmdâ€� <
			// â€œC:\Users\TechTorials\Desktop\pass.txtâ€�
			/*
			 * command.add("cmd.exe"); command.add("/c"); command.add("runas");
			 * command.add("/user:Administrator"); command.add("\"net");
			 * command.add("stop"); command.add(service.getName() + "\"");
			 * command.add("<"); command.add("\"" + adminTxt + "\"");
			 */
			command.add("cmd.exe");
			command.add("/c");
			command.add("sc");
			command.add("stop");
			// command.add("/pid");
			command.add(name);
			System.out.println(command);
			Process servicesProcess = new ProcessBuilder(command).start();
			InputStream input = servicesProcess.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));
			String line;
			StringBuffer queryResult = new StringBuffer();
			while ((line = reader.readLine()) != null) {
				queryResult.append(line);
			}
			reader.close();
			servicesProcess.destroy();
			System.out.println(queryResult.toString());
			if (queryResult.toString().toLowerCase().contains("failed") || queryResult.toString().toLowerCase().contains("error")) {
				return "Failed @stop";
			}
			System.out.println("Stop service completed succesfully!");
			return "Succes @stop";
		} catch (IOException e) {
			return "Failed @stop";
		}
	}

	public String changeStartup(String name, String mode) {
		if (mode.equals("auto") || mode.equals("demand") || mode.equals("disabled") || mode.equals("boot") || mode.equals("system")
				|| mode.equals("delayed-auto")) {
		} else {
			return "Invalid identifier";
		}
		try {
			List<String> command = new ArrayList<String>();
			command.add("cmd.exe");
			command.add("/c");
			command.add("sc");
			command.add("config");
			command.add(name);
			command.add("start=");
			command.add(mode);
			System.out.println(command);
			Process servicesProcess = new ProcessBuilder(command).start();
			InputStream input = servicesProcess.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));
			String line;
			StringBuffer queryResult = new StringBuffer();
			while ((line = reader.readLine()) != null) {
				queryResult.append(line);
			}
			reader.close();
			servicesProcess.destroy();
			if (queryResult.toString().toLowerCase().contains("failed") || queryResult.toString().toLowerCase().contains("error")
					|| queryResult.toString().toLowerCase().contains("access is denied")) {
				return "Failed @changeStartup";
			}
			System.out.println("Stop service completed succesfully!" + queryResult.toString());
			return "Succes @changeStartup";
		} catch (IOException e) {
			return "Failed @changeStartup";
		}
	}
	
	public String checkIfStarted(String name){
		for(Service eachService : servicesList){
			if(eachService.getName().equals(name)){
				String state = eachService.getState().toLowerCase();
				if(state.contains("start") || state.contains("run")){
					return "Succes @checkIfStarted";
				}else{
					return "Failed @checkIfStarted";
				}
			}
		}
		return "Failed @checkIfStarted";
	}
	
	public String checkStartMode(String name, String mode){
		for(Service eachService : servicesList){
			if(eachService.getName().equals(name)){
				String startMode = eachService.getStartMode().toLowerCase();
				if(startMode.contains(mode)){
					return "Succes @checkStartMode";
				}else{
					return "Failed @checkStartMode";
				}
			}
		}
		return "Failed @checkStartMode";
	}
	
	public String checkIfStopped(String name){
		for(Service eachService : servicesList){
			if(eachService.getName().equals(name)){
				String state = eachService.getState().toLowerCase();
				if(state.contains("stop") || state.contains("stopping")){
					return "Succes @checkIfStopped";
				}else{
					return "Failed @checkIfStopped";
				}
			}
		}
		return "Failed @checkIfStopped";
	}
	
	

	public List<Service> runningServices() {
		List<Service> running = new ArrayList<Service>();
		for (Service service : servicesList) {
			if (service.getState().toLowerCase().contains("running")) {
				running.add(service);
			}
		}
		return running;
	}

	public List<Service> stoppedServices() {
		List<Service> stopped = new ArrayList<Service>();
		for (Service service : servicesList) {
			if (service.getState().toLowerCase().contains("stopped")) {
				stopped.add(service);
			}
		}
		return stopped;
	}

	public String ordonateByState(Boolean runningFirst) {
		List<Service> services = new ArrayList<Service>();
		if (runningFirst) {
			services.addAll(runningServices());
			services.addAll(stoppedServices());
			return "runningFirst";
		} else {
			services.addAll(stoppedServices());
			services.addAll(runningServices());
		}
		this.servicesList = services;
		return "stoppedFirst";
	}
}
