package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import model.ProcessT;

public class ProcessMonitor {

	private int numberOfProcesses;
	private List<ProcessT> processList = new ArrayList<ProcessT>();

	private String totalCPU;
	private String totalMemory;

	private String adminPassword;
	private String processesListTxt = System.getProperty("user.dir")
			+ "\\processesList.txt";

	private boolean isListCreated;
	private boolean isPasswordSet;
	private boolean isTxtCreated;

	public int getNumberOfProcesses() {
		return numberOfProcesses;
	}

	public void setNumberOfProcesses(int numberOfProcesses) {
		this.numberOfProcesses = numberOfProcesses;
	}

	public String getTotalCPU() {
		return totalCPU;
	}

	public void setTotalCPU(String totalCPU) {
		this.totalCPU = totalCPU;
	}

	public String getTotalMemory() {
		return totalMemory;
	}

	public void setTotalMemory(String totalMemory) {
		this.totalMemory = totalMemory;
	}

	public String getTxtFileName() {
		return processesListTxt;
	}

	public void setTxtFileName(String txtFileName) {
		this.processesListTxt = txtFileName;
	}

	public boolean isTxtCreated() {
		return isTxtCreated;
	}

	public void setTxtCreated(boolean isTxtCreated) {
		this.isTxtCreated = isTxtCreated;
	}

	public List<ProcessT> getProcessList() {
		return processList;
	}

	public void setProcessList(List<ProcessT> processList) {
		this.processList = processList;
	}

	public boolean isListCreated() {
		return isListCreated;
	}

	public void setListCreated(boolean isListCreated) {
		this.isListCreated = isListCreated;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
		this.isPasswordSet = true;
	}

	public boolean isPasswordSet() {
		return isPasswordSet;
	}

	public void setPasswordSet(boolean isPasswordSet) {
		this.isPasswordSet = isPasswordSet;
	}

	public String connect() {
		try {
			List<String> command = new ArrayList<String>();
			// command.add("wmic");
			// command.add("/output:\"" + txt + "\"");
			// command.add("process");
			// command.add("get");
			// command.add("name,");
			// command.add("processid,");
			// command.add("sessionid,");
			// command.add("threadcount,");
			// command.add("kernelmodetime,");
			// command.add("usermodetime,");
			// command.add("workingsetsize,");
			// command.add("virtualsize,");
			// command.add("pagefileusage,");
			// command.add("privatepagecount,");
			// command.add("readoperationcount,");
			// command.add("readtransfercount,");
			// command.add("writeoperationcount,");
			// command.add("writetransfercount");
			command.add("cmd.exe");
			command.add("/c");
			command.add("tasklist");
			command.add("/nh");
			command.add(">");
			command.add(processesListTxt);
			java.lang.Process process = new ProcessBuilder(command).start();
			InputStream input = process.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					input));
			String line;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
			process.destroy();
			if (new File(processesListTxt).exists()) {
				isTxtCreated = true;
				return "Succes @connect";
			} else {
				return "Failed @connect";
			}
		} catch (IOException e) {
			return "Failed @connect";
		}
	}

	public String parse() {
		if (!isTxtCreated) {
			return "Failed @parse";
		}
		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(
					processesListTxt)));
			String line = reader.readLine();
			System.out.println("1" + line);
			line = reader.readLine();
			String[] attributesT = line.split("[ ]+");
			ProcessT process = new ProcessT(attributesT[0] + " "
					+ attributesT[1] + " " + attributesT[2], attributesT[3],
					attributesT[4], attributesT[5], attributesT[6]);
			processList.add(process);
			line = reader.readLine();
			while (line != null) {
				String[] attributes = line.split("[ ]+");
				ProcessT processT = new ProcessT(attributes[0], attributes[1],
						attributes[2], attributes[3], attributes[4]);
				processList.add(processT);
				line = reader.readLine();
			}
			reader.close();
		} catch (Exception e) {
			return "Failed @parse";
		}
		return "Succes @parse";
	}

	public String setTotalProcessesNo() {
		try {
			List<String> command = new ArrayList<String>();
			command.add("wmic");
			command.add("os");
			command.add("get");
			command.add("numberofprocesses");
			command.add("/value");
			java.lang.Process process = new ProcessBuilder(command).start();
			InputStream input = process.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					input));
			String line = reader.readLine();
			StringBuffer output = new StringBuffer();
			while (line != null) {
				output.append(line);
				line = reader.readLine();
			}
			String[] splitted = output.toString().split("=");
			numberOfProcesses = Integer.valueOf(splitted[1]);
			input.close();
			process.destroy();
		} catch (IOException e) {
			return "Failed @setTotalProcessesNo";
		}
		return "Succes @setTotalProcessesNo";
	}

	public void listProcesses() {
		for (ProcessT eachProcess : processList) {
			System.out.println(eachProcess.toString());
		}
	}

	public String create(String name) {
		String array[] = name.split("[\\\\]+");

		int n = array.length;
		if (findProcessByName(array[n - 1]).equals("Not Found")) {
			try {
				// String cmd = new String();
				Runtime.getRuntime().exec(name);
				System.out.println("Start service completed succesfully!");
			} catch (Exception e) {
				return "Failed @create";
			}
			return "Succes @create";
		} else
			return "Process already existing @create";
	}

	public String findProcessByName(String name) {
		for (ProcessT eachProcess : processList) {
			if (eachProcess.getName().equals(name))
				return "Found";
		}
		return "Not Found";
	}

	public String findProcessByPID(String PID) {
		for (ProcessT eachProcess : processList) {
			if (eachProcess.getPID().equals(PID))
				return "Found";
		}
		return "Not Found";
	}

	public String delete(String pID) {

		if (findProcessByPID(pID).equals("Found")) {
			try {
				List<String> command = new ArrayList<String>();
				command.add("cmd.exe");
				command.add("/c");
				command.add("taskkill");
				command.add("/f");
				command.add("/pid");
				command.add(pID);
				System.out.println(command);
				java.lang.Process process = new ProcessBuilder(command).start();
				InputStream input = process.getInputStream();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(input));
				String line;
				StringBuffer queryResult = new StringBuffer();
				while ((line = reader.readLine()) != null) {
					queryResult.append(line);
				}
				reader.close();
				process.destroy();
				System.out.println("Start service completed succesfully!");
			} catch (IOException e) {
				return "Failed @delete";
			}
			return "Succes @delete";
		} else
			return "Process not found @delete";
	}

	public String totalCpuUsage() {
		try {
			List<String> command = new ArrayList<String>();
			command.add("cmd.exe");
			command.add("/c");
			command.add("typeperf");
			command.add("\"\\Processor(_Total)\\% Processor Time\"");
			command.add("-sc");
			command.add("1");
			System.out.println(command);
			java.lang.Process process = new ProcessBuilder(command).start();
			InputStream input = process.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					input));
			String line = reader.readLine();
			line = reader.readLine();
			line = reader.readLine();
			StringBuffer queryResult = new StringBuffer();
			while (line != null) {
				queryResult.append(line);
				line = reader.readLine();
			}
			reader.close();
			process.destroy();
			System.out.println(queryResult);
			String middleR = queryResult.substring(queryResult
					.lastIndexOf(",\""));
			String finalR = middleR.replace(",\"", "").substring(0,
					middleR.lastIndexOf("\"") - 2);
			totalCPU = finalR;
			if (!totalCPU.isEmpty()) {
				System.out.println("CPU Usage " + totalCPU);
				System.out.println("CPU Usage updated succesfully!");
				return "Succes @totalCpuUsage";
			} else {
				return "Failed @totalCpuUsage";
			}
		} catch (IOException e) {
			return "Failed @totalCpuUsage";
		}

	}

	public String totalMemoryUsage() {
		try {
			List<String> command = new ArrayList<String>();
			command.add("cmd.exe");
			command.add("/c");
			command.add("typeperf");
			command.add("\"\\Memory\\% Committed Bytes In Use\"");
			command.add("-sc");
			command.add("1");
			System.out.println(command);
			java.lang.Process process = new ProcessBuilder(command).start();
			InputStream input = process.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					input));
			String line = reader.readLine();
			line = reader.readLine();
			line = reader.readLine();
			StringBuffer queryResult = new StringBuffer();
			while (line != null) {
				queryResult.append(line);
				line = reader.readLine();
			}
			reader.close();
			process.destroy();
			String middleR = queryResult.substring(queryResult
					.lastIndexOf(",\""));
			String finalR = middleR.replace(",\"", "").substring(0,
					middleR.lastIndexOf("\"") - 2);
			totalMemory = finalR;

			if (!totalMemory.isEmpty()) {
				System.out.println("Memory Usage " + totalMemory);
				System.out.println("Memory Usage updated succesfully!");
				return "Succes @totalMemoryUsage";
			} else {
				return "Failed @totalMemoryUsage";
			}
		} catch (IOException e) {
			return "Failed @totalMemoryUsage";
		}

	}
}
