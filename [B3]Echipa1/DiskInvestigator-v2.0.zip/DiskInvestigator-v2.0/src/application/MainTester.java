package application;

import model.Service;
import controller.ProcessMonitor;
import controller.ServiceMonitor;

public class MainTester {

	public static void main(String[] args) {
		ProcessMonitor pm = new ProcessMonitor();
		pm.totalCpuUsage();
		pm.totalMemoryUsage();
//		System.out.println(pm.connect());
//		System.out.println(pm.parse());
//		System.out.println(pm.setTotalProcessesNo());
//		pm.listProcesses();
//		System.out.println(pm.create("dwasda.exe"));
//		System.out.println(pm.create("notepad.exe"));
//		System.out.println(pm.delete("3164"));
//		ServiceMonitor sm = new ServiceMonitor();
//		sm.initiliaze();
//		System.out.println(sm.connect());
//		System.out.println(sm.parse());
//		sm.listComponents();
//		Service service = new Service();
//		service.setName("AppXSvc");
//		service.setPID(2348);
//		System.out.println(sm.stop(service));
//		System.out.println(sm.start(service));
		
	}

}
