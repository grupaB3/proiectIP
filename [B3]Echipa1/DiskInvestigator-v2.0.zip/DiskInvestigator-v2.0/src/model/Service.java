package model;

public class Service extends Component{

	private String name;
	private int pID;
	private String description;
	private String startMode;
	private String state;
	private String startName;

	public Service() {
		super();
	}

	public Service(String name, int pID, String description, String startMode, String state, String startName) {
		super();
		this.name = name;
		this.pID = pID;
		this.description = description;
		this.startMode = startMode;
		this.state = state;
		this.startName = startName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPID() {
		return pID;
	}

	public void setPID(int pID) {
		this.pID = pID;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStartMode() {
		return startMode;
	}

	public void setStartMode(String startMode) {
		this.startMode = startMode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStartName() {
		return startName;
	}

	public void setStartName(String startName) {
		this.startName = startName;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Service [name=");
		builder.append(name);
		builder.append(", PID=");
		builder.append(pID);
		builder.append(", description=");
		builder.append(description);
		builder.append(", startMode=");
		builder.append(startMode);
		builder.append(", state=");
		builder.append(state);
		builder.append(", startName=");
		builder.append(startName);
		builder.append("]");
		return builder.toString();
	}

}
